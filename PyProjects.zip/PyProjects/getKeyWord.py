import jieba.analyse

f = open(r"data.txt", "r", encoding = "gbk", errors = "ignore")

text = ""

for line in f:
    text = text + line

kwords = jieba.analyse.extract_tags(text, 200)

print(kwords)
