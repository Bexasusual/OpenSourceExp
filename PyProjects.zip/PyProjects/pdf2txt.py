from pdfminer.pdfparser import PDFParser, PDFDocument
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.converter import PDFPageAggregator
from pdfminer.layout import LTTextBoxHorizontal, LAParams
from pdfminer.pdfinterp import PDFTextExtractionNotAllowed
import logging

logging.propagate = False
logging.getLogger().setLevel(logging.ERROR)

pdf_filename = "big.pdf"
txt_filename = "big.txt"

device = PDFPageAggregator(PDFResourceManager(), laparams=LAParams())
interpreter = PDFPageInterpreter(PDFResourceManager(), device)

doc = PDFDocument()
parser = PDFParser(open(pdf_filename, 'rb'))
print("Done1")
parser.set_document(doc)
print("Done2")
doc.set_parser(parser)
print("Done3")
doc.initialize()
print("Done4")

if not doc.is_extractable:
    raise PDFTextExtractionNotAllowed
else:
    with open(txt_filename, 'w', encoding="utf-8") as fw:
        print("num page:{}".format(len(list(doc.get_pages()))))
        count = 0
        for page in doc.get_pages():
            print("page:", ++count)
            interpreter.process_page(page)
            layout = device.get_result()
            for x in layout:
                if isinstance(x, LTTextBoxHorizontal):
                    results = x.get_text()
                    fw.write(results)
