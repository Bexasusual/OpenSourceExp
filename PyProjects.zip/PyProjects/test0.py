#coding = utf-8
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

chrome_opt = Options()
chrome_opt.add_argument('--headless')
chrome_opt.add_argument('--disable-gpu')
chrome_opt.add_argument('--window-size=1366,768')
chrome_opt.add_argument('--no-sandbox')

browser = webdriver.Chrome(chrome_options = chrome_opt)
url = "https://www.baidu.com/"
browser.get(url)
print (browser.page_source)
browser.quit()
