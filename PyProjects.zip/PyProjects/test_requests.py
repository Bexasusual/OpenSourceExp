#coding = utf-8
import requests
r = requests.get("http://www.ubinec.org/index.php?c=download&id=1876", verify = False)
r.encoding = r.apparent_encoding
with open("./testdownload.pdf", "wb") as f:
  f.write(r.content)
