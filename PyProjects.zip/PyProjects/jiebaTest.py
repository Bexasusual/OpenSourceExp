# -*- coding: utf-8 -*-
"""
Created on Sat Mar 14 17:06:34 2020

@author: Xiaoli
"""

import jieba

f = open(r"testdownload.txt", "r", encoding = "gbk", errors = "ignore")

text = ""

for line in f:
    text = text + line

seg_list = jieba.cut(text, cut_all = False)
# print(type(seg_list)) #class 'generator'
with open("testresult.txt", "w", encoding = "gbk", errors = "ignore") as f_result:
        f_result.write(" | ".join(seg_list))
