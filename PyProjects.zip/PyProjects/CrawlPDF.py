import os
import requests
from requests import RequestException
import re
import time
from bs4 import BeautifulSoup

def DownloadPdf(url):
    try:
        filename = url.split('/')[-1]  # 以/为分割符保留最后一段
        if not os.path.exists(filename):
            r = requests.get(url)
            f = open("./ebook/" + filename, "wb")
            f.write(r.content)
            f.close()
            print("download ok")
        else:
            print("文件已经存在，跳过下载")
    except Exception as reason:
        print("出错原因：%s" % str(reason))


def getPage(url):
    try:
        page = requests.get(url)
        html = page.content
        return html
    except RequestException as reason:
        print("出错原因：%s" % str(reason))


def getPdfPage(bookurl):
    html2 = getPage(bookurl)
    # print(html)
    soup2 = BeautifulSoup(html2, "lxml", from_encoding='utf-8')  # 网页为lxml格式
    # 查找pdf文件下载的节点
    tags2 = soup2.find_all('span', class_="download-links")
    print("pdf tags：%s" % str(tags2))

    for list2 in tags2:
        try:
            herf2 = list2.find_all('a')
            # 正则匹配，每本书介绍页面的url
            bookDownloadUr = str(re.findall("http?://(?:[-\w.])+/(?:[-\w.])+/(?:[-\w.,'\s.])+", str(herf2)))
            print(bookDownloadUr)
            # 移除字符串首尾的[]'"
            bookDownloadUrl = bookDownloadUr.strip("[']")
            bookDownloadUrl = bookDownloadUrl.strip('"')
        except Exception as reason:
            print("出错原因：%s" % str(reason))  # log记录

        # 匹配 pdf文档
        if '.pdf' in bookDownloadUrl:
            if '.epub' in bookDownloadUrl:
                print('')
            else:
                print("下载书籍网址：" + bookDownloadUrl)
                DownloadPdf(bookDownloadUrl)
        else:
            print('epub文件，跳过下载')

def getPageList(html):
    soup = BeautifulSoup(html, "lxml", from_encoding='utf-8')

    tags = soup.find_all('h2', class_="entry-title")

    for list1 in tags:
        try:
            herf = list1.find_all('a')
            bookname = herf[0].string  # 每页书籍的名称
            print("书籍名称：%s" % str(bookname))

            # 正则匹配，每本书介绍页面的url
            booku = str(re.findall('http?://(?:[-\w.])+/(?:[-\w.])+', str(herf)))

            # 移除字符串首尾的[]
            bookurl = booku.strip("[']")
            getPdfPage(bookurl)

        except Exception as reason:
            print("Error: %s" % str(reason))

        time.sleep(3)

if __name__ == "__main__":
    url = "http://www.allitebooks.org/page/"
    for pageNum in range(1, 3):
        print("pageNum = " + str(pageNum))
        urlNew = url + str(pageNum)
        getPageList(getPage(urlNew))
