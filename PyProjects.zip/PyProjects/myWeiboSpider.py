# -*- coding: utf-8 -*-
import time
import datetime
import re
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
import xlwt

import jieba.analyse

# 先调用无界面浏览器PhantomJS或Firefox
# driver = webdriver.PhantomJS()
# driver = webdriver.Firefox()
# 下载chrome：https://www.google.cn/intl/zh-CN/chrome/
# 要使用Chrome浏览器，必须得有chromedriver
# 并且需要设置环境变量PATH
# 参考：https://www.cnblogs.com/lfri/p/10542797.html
# 如80.0.3987.132版本的chrome对应下载80.0.3987.16即可
chrome_opt = Options()
chrome_opt.add_argument('--headless')
chrome_opt.add_argument('--disable-gpu')
chrome_opt.add_argument('--window-size=1366,768')
chrome_opt.add_argument('--no-sandbox')

driver = webdriver.Chrome(chrome_options = chrome_opt)


# ********************************************************************************
#                            第一步: 登陆login.sina.com
#                     这是一种很好的登陆方式，有可能有输入验证码
#                          登陆之后即可以登陆方式打开网页
# ********************************************************************************

def LoginWeibo(username, password):
    try:
        # 输入用户名/密码登录
        print('准备登陆Weibo.cn网站...')
        driver.get("http://login.sina.com.cn/")
        elem_user = driver.find_element_by_name("username")
        elem_user.send_keys(username)  # 用户名
        elem_pwd = driver.find_element_by_name("password")
        elem_pwd.send_keys(password)  # 密码
        elem_sub = driver.find_element_by_xpath("//input[@class='W_btn_a btn_34px']")
        elem_sub.click()  # 点击登陆 因无name属性

        try:
            # 输入验证码
            time.sleep(10)
            elem_sub.click()
        except:
            # 不用输入验证码
            pass

        # 获取Coockie 推荐资料：http://www.cnblogs.com/fnng/p/3269450.html
        print('Crawl in ', driver.current_url)
        print('输出Cookie键值对信息:')
        for cookie in driver.get_cookies():
            print(cookie)
            for key in cookie:
                print(key, cookie[key])
        print('登陆成功...')
    except Exception as e:
        print("Error: ", e)
    finally:
        print('End LoginWeibo!\n')


# ********************************************************************************
#                  第二步: 访问http://s.weibo.com/页面搜索结果
#               输入关键词、时间范围，得到所有微博信息、博主信息等
#                     考虑没有搜索结果、翻页效果的情况
# ********************************************************************************

def GetSearchContent(key):
    driver.get("http://s.weibo.com/")
    print('搜索热点主题：')

    # 输入关键词并点击搜索
    item_inp = driver.find_element_by_xpath("//input[@type='text']")
    #item_inp = driver.find_element_by_xpath("//*[@id='pl_homepage_search']/div/div[2]/div/input")
    item_inp.send_keys(key)
    item_inp.send_keys(Keys.RETURN)  # 采用点击回车直接搜索

    time.sleep(5)
    # 获取搜索词的URL，用于后期按时间查询的URL拼接
    current_url = driver.current_url
    current_url = current_url.split('&')[0]  # http://s.weibo.com/weibo/%25E7%258E%2589%25E6%25A0%2591%25E5%259C%25B0%25E9%259C%2587

    global start_stamp
    global page


    # 需要抓取的开始和结束日期
    start_date = datetime.datetime(2019, 5, 20)
    end_date = datetime.datetime(2019, 5, 21)
    delta_date = datetime.timedelta(days=1)
    # 需要抓取的地区   37:2代表山东青岛
    #regionName,regionID = regionAndID
    #region = 'custom:'+str(regionID)+':1000'       ################

    # 每次抓取一天的数据
    start_stamp = start_date
    end_stamp = start_date + delta_date

    global outfile
    global sheet

    outfile = xlwt.Workbook(encoding='utf-8')

    while end_stamp <= end_date:
        page = 1

        # 每一天使用一个sheet存储数据
        sheet = outfile.add_sheet(start_stamp.strftime("%Y-%m-%d-%H"))
        initXLS(key)

        # 通过构建URL实现每一天的查询
        #url = current_url + '&typeall=1&suball=1&timescope=custom:' + start_stamp.strftime(
        #    "%Y-%m-%d-%H") + ':' + end_stamp.strftime("%Y-%m-%d-%H") + '&region='+ region + '&Refer=g'
        url = current_url + '&typeall=1&suball=1&timescope=custom:' + start_stamp.strftime(
                "%Y-%m-%d-%H") + ':' + end_stamp.strftime("%Y-%m-%d-%H") + '&Refer=g'
        #url = 'https://s.weibo.com/weibo?q=%E9%9B%BE%E9%9C%BE&region=custom:37:2&typeall=1&suball=1&timescope=custom:2018-01-01-17:2018-01-01-19&Refer=g'
        #url = current_url + '&typeall=1&suball=1&timescope=custom:' +'2019-05-21-23:2019-05-22-0'+ '&region='+ region + '&Refer=g'
        driver.get(url)

        handlePage()  # 处理当前页面内容

        start_stamp = end_stamp
        end_stamp = end_stamp + delta_date


# time.sleep(1)

# ********************************************************************************
#                  辅助函数，考虑页面加载完成后得到页面所需要的内容
# ********************************************************************************

# 页面加载完成后，对页面内容进行处理
def handlePage():
    while True:
        # 之前认为可能需要sleep等待页面加载，后来发现程序执行会等待页面加载完毕
        # sleep的原因是对付微博的反爬虫机制，抓取太快可能会判定为机器人，需要输入验证码
        time.sleep(1)
        # 先行判定是否有内容
        if checkContent():
            print("getContent")
            getContent()
            # 先行判定是否有下一页按钮
            if checkNext():
                # 拿到下一页按钮
                next_page_btn = driver.find_element_by_css_selector("#pl_feedlist_index > div.m-page > div > a.next")
                next_page_btn.click()
            else:
                print("no Next")
                break
        else:
            print("no Content")
            break


# 判断页面加载完成后是否有内容
def checkContent():
    # 有内容的前提是有“导航条”？错！只有一页内容的也没有导航条
    # 但没有内容的前提是有“pl_noresult”
    try:
        driver.find_element_by_xpath("//div[@class='card card-no-result s-pt20b40']")
        flag = False
    except:
        flag = True
    return flag


# 判断是否有下一页按钮
def checkNext():
    try:
        driver.find_element_by_css_selector("#pl_feedlist_index > div.m-page > div > a.next")
        flag = True
    except:
        flag = False
    return flag


# 判断是否有展开全文按钮
def checkqw():
    try:
        driver.find_element_by_xpath(".//div[@class='content']/p[@class='txt']/a")
        flag = True
    except:
        flag = False
    return flag


# 在添加每一个sheet之后，初始化字段
def initXLS(key):
    name = ['微博内容', '发布时间', '转发', '评论', '赞']

    global row
    global outfile
    global sheet

    row = 0
    for i in range(len(name)):
        sheet.write(row, i, name[i])
    row = row + 1
    outfile.save("./XLS/" + key + ".xls")


# 将dic中的内容写入excel
def writeXLS(dic, key):
    global row
    global outfile
    global sheet

    for k in dic:
        for i in range(len(dic[k])):
            sheet.write(row, i, dic[k][i])
        row = row + 1
    outfile.save("./XLS" + key + ".xls")


# 在页面有内容的前提下，获取内容
def getContent():
    # 寻找到每一条微博的class
    try:
        # nodes = driver.find_elements_by_xpath("//div[@class='WB_cardwrap S_bg2 clearfix']")
        # nodes = driver.find_elements_by_xpath("//div[@class='card-wrap']")
        nodes = driver.find_elements_by_xpath("//div[@class='card-wrap']/div[@class='card']")
    except Exception as e:
        print(e)

    # 在运行过程中微博数==0的情况，可能是微博反爬机制，需要输入验证码
    if len(nodes) == 0:
        input("请在微博页面输入验证码！")
        url = driver.current_url
        driver.get(url)
        getContent()
        return

    dic = {}

    global page
    print(start_stamp.strftime("%Y-%m-%d-%H"))
    print('页数:', page)
    page = page + 1
    print('微博数量', len(nodes))

    for i in range(len(nodes)):
        dic[i] = []

        # 判断展开全文和网页链接是否存在
        try:
            nodes[i].find_element_by_xpath(".//div[@class='content']/p[@class='txt']/a[@action-type='fl_unfold']").is_displayed()
            flag = True
        except:
            flag = False
        # 获取微博内容
        try:
            if flag:
                nodes[i].find_element_by_xpath(".//div[@class='content']/p[@class='txt']/a[@action-type='fl_unfold']").click()
                time.sleep(1)
                WBNR = nodes[i].find_element_by_xpath(".//div[@class='content']/p[2]").text.replace("\n","")
                # 判断发布位置是否存在
                try:
                    nodes[i].find_element_by_xpath(".//div[@class='content']/p[@class='txt']/a/i[@class='wbicon']").is_displayed()
                    flag = True
                except:
                    flag = False
                # 获取微博发布位置
                try:
                    if flag:
                        pattern = nodes[i].find_elements_by_xpath(".//div[@class='content']/p[2]/a[i[@class='wbicon']]")
                        if isinstance(pattern,list):
                            text = [p.text for p in pattern]
                            FBWZ = [loc for loc in [re.findall('^2(.*$)', t) for t in text] if len(loc) > 0][0][0]
                        else:
                            text = pattern.text
                            FBWZ = re.findall('^2(.*$)',text)[0]
                    else:
                        FBWZ = ''
                except:
                    FBWZ = ''
            else:
                WBNR = nodes[i].find_element_by_xpath(".//div[@class='content']/p[@class='txt']").text.replace("\n","")
                # 判断发布位置是否存在
                try:
                    nodes[i].find_element_by_xpath(".//div[@class='content']/p[@class='txt']/a/i[@class='wbicon']").is_displayed()
                    flag = True
                except:
                    flag = False
                # 获取微博发布位置
                try:
                    if flag:
                        pattern = nodes[i].find_elements_by_xpath(".//div[@class='content']/p[@class='txt']/a[i[@class='wbicon']]")
                        if isinstance(pattern,list):
                            text = [p.text for p in pattern]
                            FBWZ = [loc for loc in [re.findall('^2(.*$)', t) for t in text] if len(loc) > 0][0][0]
                        else:
                            text = pattern.text
                            FBWZ = re.findall('^2(.*$)',text)[0]
                    else:
                        FBWZ = ''
                except:
                    FBWZ = ''
        except:
            WBNR = ''
        print('微博内容:', WBNR)
        dic[i].append(WBNR)

        try:
            # FBSJ = nodes[i].find_element_by_xpath(".//div[@class='feed_from W_textb']/a[@class='W_textb']").text
            FBSJ = nodes[i].find_element_by_xpath(".//div[@class='content']/p[@class='from']/a[1]").text
        except:
            FBSJ = ''
        print('发布时间:', FBSJ)
        dic[i].append(FBSJ)


        try:
            ZF_TEXT = nodes[i].find_element_by_xpath(".//a[@action-type='feed_list_forward']").text
            #            ZF_TEXT = nodes[10].find_element_by_xpath(".//a[@action-type='feed_list_forward']").text
            #            ZF_TEXT.split(' ')[1]
            if ZF_TEXT == '转发':
                ZF = 0
            else:
                ZF = int(ZF_TEXT.split(' ')[1])
        except:
            ZF = 0
        print('转发:', ZF)
        dic[i].append(ZF)

        try:
            # PL_TEXT = nodes[i].find_element_by_xpath(".//a[@action-type='feed_list_comment']//em").text#可能没有em元素
            PL_TEXT = nodes[i].find_element_by_xpath(".//a[@action-type='feed_list_comment']").text  # 可能没有em元素
            # nodes[10].find_element_by_xpath(".//a[@action-type='feed_list_comment']").text
            if PL_TEXT == '评论':
                PL = 0
            else:
                PL = int(PL_TEXT.split(' ')[1])
        except:
            PL = 0
        print('评论:', PL)
        dic[i].append(PL)

        try:
            ZAN_TEXT = nodes[i].find_element_by_xpath(".//a[@action-type='feed_list_like']//em").text  # 可为空
            # ZAN_TEXT = nodes[10].find_element_by_xpath(".//a[@action-type='feed_list_like']").text #可为空
            if ZAN_TEXT == '':
                ZAN = 0
            else:
                ZAN = int(ZAN_TEXT)
        except:
            ZAN = 0
        print('赞:', ZAN)
        dic[i].append(ZAN)
        print('\n')

    # 写入Excel
    writeXLS(dic, key)


# *******************************************************************************
#                                程序入口
# *******************************************************************************
if __name__ == '__main__':
    f = open(r"data.txt", "r", encoding = "gbk", errors = "ignore")
    text = ""
    for line in f:
        text = text + line
    kwords = jieba.analyse.extract_tags(text, 200)
    print("Total:", len(kwords))
    print("KeyWords:", kwords)

    # 定义变量
    username = 'xxxxxx'  # 输入你的用户名
    password = 'xxxxxx'  # 输入你的密码

    # 操作函数
    LoginWeibo(username, password)  # 登陆微博
    # 搜索热点微博爬取评论
    # 关键词请根据实际需要进行替换
    # 请搜索和疫情有关的一些非敏感关键词
    # 注意：如果输入的是“疫情”“武汉”“中国”这样的敏感词汇，微博不会返回给你任何结果
    # 请尽量输入疫情相关又不会敏感的词汇，可以输入一些疫情支援人员的姓名试试看
    # key = '#赵丽颖#'
    # GetSearchContent(key)
    for key in kwords:
        real_key = "#" + key + "#"
        GetSearchContent(real_key)
