(function($) {

  // JS goes here

})(jQuery);
